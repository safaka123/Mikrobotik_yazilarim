
*************  dikkat ******************************

winamp program�n� ingilizce kurun plugin ingilizce de �al��abiliyor. 

Ben xp de denedim. 

kendi versiyonunuza g�re plugin �zerinde de�i�iklik yapma �ans�n�z olabilir. 

plugin k�sm�:

modMP3.bas
winamp_saf.bas


