# uart-int

simple uart example using interrupts and SPL functions.
