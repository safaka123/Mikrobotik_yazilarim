# uart-ringbuffer.c

Adopted HardwareSerial.cpp from arduino-1.0 for use with the STM8S and SDCC
using SPL functions.
