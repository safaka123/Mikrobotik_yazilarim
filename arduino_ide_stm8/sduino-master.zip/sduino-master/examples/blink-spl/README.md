# blink_spl.c

Blink a LED using SPL functions and the SDCC compiler. Example from
http://www.mikrocontroller.net/articles/STM8S-Discovery
modified for the stm8s103f3 board (LED at PD5).
