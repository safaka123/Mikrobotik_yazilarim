# uart-spl

simple uart example using SPL functions. Sending only, polling only, no
interrupts.

