# Contact


### Bug reports and other issues tightly related to the repository

[github issue tracker](https://github.com/tenbaht/sduino/issues).


### More general topics and suggestions

The [STM8 board](http://stm32duino.com/viewforum.php?f=52) of the
stm32duino forum. It will help to catch my attention to prefix your topic
with "[sduino]".

Please note that after registering on that forum, you are
**required** to post an introduction in the new user board first in order to
aquire the right to post or reply in any other board. Roger is strict on
that.


### email

Please find my address in the commit messages of the repository (as a simple
captcha test) or use the alias address sduino@gmx.de
