# HardwareSerial

Uses the UART. API similar to Arduino. Single instance only.
Pre-instanciated.

This page is only a stub.


## API
## Example
## Implementation details
## Possible impovements
