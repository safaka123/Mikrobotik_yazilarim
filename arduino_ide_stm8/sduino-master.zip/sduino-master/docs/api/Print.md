# Print

Formatting functions for use with other output libraries. Involves serious
preprocessor magic. See the [migration guidelines](../api/migration.md) and
the [xmacro description](../developer/macro.md)

This page is only a stub.


## API
## Example
## Implementation details
## Possible impovements
