# SPI

Real hardware-SPI up to 10MHz. No interrupt support yet.

This page is only a stub.


## API
## Example
## Implementation details
## Possible impovements
