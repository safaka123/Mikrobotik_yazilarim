#include "HardwareSerial.c.h"
/**
 */
uint8_t HardwareSerial(void)
{
    return initialized;
}

