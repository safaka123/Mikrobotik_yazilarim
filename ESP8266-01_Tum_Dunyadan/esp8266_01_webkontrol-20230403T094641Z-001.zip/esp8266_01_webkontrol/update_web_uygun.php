<?php
 $conn="";
 $dene="";

$id = $GLOBALS["webid"];
    $status= $GLOBALS["websta"];
    


 $dbhost = "localhost";
 $dbuser = "database user";
 $dbpass = "XXXXXX";
 $dbname = "database name";

 
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$dbname);


if ($conn->connect_error) {
    die('Connect Error (' . $conn->connect_errno . ') '
            . $conn->connect_error);
}

if (mysqli_connect_error()) {
    die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());
}




 //echo "Connected successfully<br>";

//echo $id;
//echo "<br>";
//echo $status;
//echo "<br>";

if ($status=="on"){
$sql = "UPDATE led SET status='on' WHERE id=$id"; 
}
 
 if ($status=="off"){
$sql = "UPDATE led SET status='off' WHERE id=$id"; 
}
 
if ($conn->query($sql) === TRUE) {
    //echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}



    
 //echo "Connected  SON<br>";
 
 $conn -> close();

   
?>