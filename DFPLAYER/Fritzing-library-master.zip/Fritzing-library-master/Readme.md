DFRobot Fritzing-library
========================

This is the Official DFRobot [Fritzing](http://fritzing.org/)library.

If you would like to just use the parts then just download DFRobot_fritzing_library.fzbz and import the parts bin 
into Fritzing (File -> Parts Bin -> Open -> From File...)


Please give us feedback. Let us know if there are any bugs. We will promptly make any necessary updates.
