package de.ullisroboterseite.ursai2tcpserver;

import java.io.*;

/**
 * Stellt eine nicht blockierende Methode zum Einlesen einer Zeile bereit.
 */
public class LineReader {
    static final String LOG_TAG = UrsAI2TcpServer.LOG_TAG;

    Reader in;
    StringBuilder sb = new StringBuilder();

    boolean skipLF = false;
    char ignoreTestChar;
    char nullChar = (char) 0;

    /**
     * Initialisiert eine neue Instanz der LineReader-Klasse.
     * @param in Konfiguriertes Reader-Objekt, das die empfangengen Zeichen bereit stellt.
     */
    LineReader(Reader in, char ignoreTestChar) {
        this.in = in;
        this.ignoreTestChar = ignoreTestChar;
    }

    /**
     * Liest nicht blockierend eine Textzeile ein.
     * @return Die eingelesene Zeile oder null, wenn keine komplette Zeile vorliegt.
     * @throws IOException Falls ein I/O-Fehler auftritt.
     */
    String readLine() throws IOException {
        String s = null;

        while (in.ready()) { // Kein weiteres Zeichen vorhanden
            int i = in.read();
            if (i == -1) // Sicherheitshalber, sollte es wegen ready() aber nicht geben
                return null;

            char c = (char) i;

            if (c == '\r') { // Zeilenende
                s = sb.toString();
                sb.setLength(0);
                skipLF = true; // LF kann folgen
                return s;
            }

            if (c == '\n') {
                if (skipLF) { // Das Zeichen vorher war CR, LF ignorieren
                    skipLF = false;
                    continue;
                } else {
                    s = sb.toString(); // Ansonsten Zeilenende
                    sb.setLength(0);
                    return s;
                }
            }

            // Testzeichen ignorieren
            if ((ignoreTestChar != nullChar) && (c != ignoreTestChar))
                sb.append(c); // Speichern

            skipLF = false; // Anderes Zeichen: LF folgt nicht unmittelbar auf CR.
        } // end while

        return null;
    }
}
