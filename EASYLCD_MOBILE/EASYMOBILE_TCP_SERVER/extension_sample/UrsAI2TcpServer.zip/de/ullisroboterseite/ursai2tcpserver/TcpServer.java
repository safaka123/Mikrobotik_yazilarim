package de.ullisroboterseite.ursai2tcpserver;

import java.net.*;
import java.util.*;
import java.nio.charset.Charset;

import android.util.Log;

public class TcpServer {
   static final String LOG_TAG = UrsAI2TcpServer.LOG_TAG;

   private WorkerThread workerThread;
   private volatile boolean stopRequest = false;

   int lastClientID = 0;

   UrsAI2TcpServer eventListener;
   int socketTimeout;
   Charset charset;

   ServerSocket serverSocket = null;

   Map<Integer, TcpClient> clients = new HashMap<>();

   char ignoreTestChar;
   int crlfDelay;

   /**
    * Initialisiert eine neue Instanz der UrsAI2TcpServer-Klasse
    * @param eventListener Nimmt die Events entgegen
    */
   TcpServer(UrsAI2TcpServer eventListener, char ignoreTestChar, int crlfDelay) {
      this.eventListener = eventListener;
      this.ignoreTestChar = ignoreTestChar;
      this.crlfDelay = crlfDelay;
   }

   /**
    * Startet den Server-Thread.
    * @param port Port für den ServerSocket.
    * @return
    */
   public void start(int port, int socketTimeout, Charset charset) {
      if (serverSocket != null) {
         stop();
      }

      this.socketTimeout = socketTimeout;
      this.charset = charset;

      eventListener.serverStarted();
      try {
         serverSocket = new ServerSocket(port);
      } catch (Exception e) {
         Log.d(LOG_TAG, "Error TcpServer.start: " + e.toString());
         eventListener.serverStopped(ErrorCode.CannotCreateServerSocket, e);
         return;
      }

      stopRequest = false;
      workerThread = new WorkerThread();
      workerThread.start();

      return;
   }

   /**
   * Stoppt den Listener-Thread und hebt die Verbindung mit den Clients auf.
    */
   public void stop() {
      if (serverSocket == null)
         return;

      stopRequest = true;

      try {
         serverSocket.close();
      } catch (Exception e) {
         // nichts tun
      }
      serverSocket = null;
   }

   /**
    * Liefert den zur ID gehörenden Client (null, wenn nicht vorhanden)
    * @param clientID
    * @return
    */
   TcpClient getClient(int clientID) {
      return clients.get(clientID);
   }

   int getConnectedClients(){
      return clients.size();
   }

   void removeClient(int clientID){
      clients.remove(clientID);
   }

   void incrementlastClientID() {
      lastClientID++;
      if (lastClientID > 20000)
         lastClientID = 0;
      while (clients.containsKey(lastClientID))
         lastClientID++;
   }

   // Der eigentliche Thread
   class WorkerThread extends Thread {
      @Override
      public void run() {
         Log.d(LOG_TAG, "TcpServer thread started");

         Exception abortException = null;

         while (true) {
            try {
               Socket client = serverSocket.accept();
               if (!stopRequest) { // nach dem Stoprequest keine Clients mehr annehmen
                  clients.put(lastClientID, new TcpClient(lastClientID, eventListener, client, socketTimeout, charset, ignoreTestChar));
                  eventListener.clientConnected(lastClientID, client.getInetAddress().toString().substring(1));
                  incrementlastClientID();
               } else
                  try {
                     client.close(); // den Client nicht annehmen!
                  } catch (Exception e1) {
                     // nichts tun
                  }
            } catch (Exception ex) {
               abortException = ex;
               break;
            } // catch
         } // while

         // Disconnect Clients;
         for (Map.Entry<Integer, TcpClient> entry : clients.entrySet()) {
            TcpClient client = entry.getValue();
            try {
               client.disconnect();
            } catch (Exception e) {
               // nichts tun
            }
         }
         clients.clear();

         if (stopRequest) {
            Log.d(LOG_TAG, "Server stopped");
            eventListener.serverStopped(ErrorCode.NoError, null);
         } else {
            Log.d(LOG_TAG, "TcpServer.aborted: " + abortException.toString());
            eventListener.serverStopped(ErrorCode.ServerAborted, abortException);
         }
      } // run
   }
}
