package de.ullisroboterseite.ursai2tcpserver;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.charset.Charset;

import android.util.Log;

public class TcpChannel {
    static final String LOG_TAG = UrsAI2TcpServer.LOG_TAG;
    TcpClient client;
    Socket socket = null;
    OutputStream os;
    InputStream is;
    OutputStreamWriter writer;
    LineReader reader;

    /**
     * Erstellt eine neue Instanz der TcpChannel-Klasse
     * @param client Verwaltungsobjekt
     */
    TcpChannel(TcpClient client, Socket socket, int socketTimeout, Charset charset, char ignoreTestChar)
            throws Exception {
        this.client = client;
        this.socket = socket;

        try {
            socket.setSoTimeout(socketTimeout);
            Log.d(LOG_TAG, "NoDelay " + socket.getTcpNoDelay());
            socket.setTcpNoDelay(true);
            // Input- und Output-Streams anlegen.
            os = socket.getOutputStream();
            is = socket.getInputStream();
            reader = new LineReader(new InputStreamReader(is, charset), ignoreTestChar);
            writer = new OutputStreamWriter(os, charset);
        } catch (Exception e) {
            disconnect();
            throw e;
        }

    }

    /**
     * Schließt die Verbindung.
     */
    void disconnect() {
        try {
            os.close();
            os = null;
        } catch (Exception e) {
            // Nothing to do
        }
        try {
            is.close();
            is = null;
        } catch (Exception e) {
            // Nothing to do
        }
        try {
            socket.close();
            socket = null;
        } catch (Exception e) {
            // Nothing to do
        }
    }

    /**
     * Liest nicht blockierend eine Textzeile ein.
     * @return Die eingelesene Zeile oder null, wenn keine komplette Zeile vorliegt.
     * @throws IOException Falls ein I/O-Fehler auftritt.
     */
    String readLine() throws IOException {
        return reader.readLine();
    }

    // https://stackoverflow.com/questions/969866/java-detect-lost-connection#answer-17889321
    // Es sind zwei Schreib-Operationen notwendig, bevor eine abgebrochene Verbindung erkannt wird.

    /**
     * Schreibt einen String in den Outputstream
     * @param msg Die zu schreibende Nachricht
     * @param doFlush true: hängt ein (CR)LF an und führt flush aus.
     * @param crlfDelay Wenn > 0: Verzögerung zwischen Daten und CrLf
     */
    void out(final String msg, final boolean doFlush, final boolean crlf, final int crlfDelay) {
        Runner.start(new Runnable() {
            public void run() {
                try {
                    writer.write(msg);
                    if (doFlush) {
                        if (crlfDelay > 0) {
                            writer.flush();
                            try {
                                Thread.sleep(200);
                            } catch (Exception e) {
                                // nichts tun
                            }
                        }
                        if (crlf)
                            writer.write("\r\n");
                        else
                            writer.write("\n");
                        writer.flush();
                    }
                } catch (Exception e) {
                    client.ioError(e);
                }
            } // run
        }); // Runnable
    }

    /**
    * Schreibt mit Verzögerung zweimal das Testzeichen.
    * @param ignoreTestChar
    * @param crlfDelay
    */
    void testConnection(final char ignoreTestChar, final int crlfDelay) {
        Runner.start(new Runnable() {
            public void run() {
                try {
                    writer.write(ignoreTestChar);
                    writer.flush();
                    try {
                        Thread.sleep(200);
                    } catch (Exception e) {
                        // nichts tun
                    }
                    writer.write(ignoreTestChar);
                    writer.flush();
                } catch (Exception e) {
                    client.ioError(null);
                }
            } // run
        }); // Runnable
    }
}