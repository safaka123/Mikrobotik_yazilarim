package de.ullisroboterseite.ursai2tcpserver;

enum ErrorCode {
    NoError(0, ""), //
    CannotCreateServerSocket(1,"Cannot create server socket."),// Start
    ServerAborted(2,"Server stopped due to an error."),//
    ConnectionFault(3, "Connection fault."), // Write, Writeln
    InvalidClientID(4,"Invalid ClientID."),// Write, Writeln, TestConnection

    InternalError(99, "Internal error.") //
    ;

    public final String errorText;
    public final int errorCode;

    ErrorCode(int code, String text) {
        this.errorCode = code;
        errorText = text;
    }

    @Override
    public String toString() {
        return errorText;
    }

    boolean isError(){
        return this != ErrorCode.NoError;
    }
};
