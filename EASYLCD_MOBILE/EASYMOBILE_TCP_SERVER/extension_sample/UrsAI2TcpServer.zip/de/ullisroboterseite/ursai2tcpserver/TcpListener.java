package de.ullisroboterseite.ursai2tcpserver;

import java.net.*;

import android.util.Log;

/*
 * Thread, der auf eingehende Daten lauscht.
 *
 * Meldet an TcpClient:
 * - messageReceived
 * - connectionStopped
 */
public class TcpListener {
    static final String LOG_TAG = UrsAI2TcpServer.LOG_TAG;

    private WorkerThread workerThread;
    private volatile boolean stopRequest = false;
    private volatile Exception errorCause = null;

    private TcpClient client;
    private TcpChannel channel;

    TcpListener(TcpClient client) {
        this.client = client;
    }

    /**
     * Startet den Listener-Thread.
     * @param channel TcpChannel zu Einlesen der Empfangsdaten
     */
    public synchronized void start(TcpChannel channel) {
        this.channel = channel;
        errorCause = null;
        workerThread = new WorkerThread();
        workerThread.start();
    }

    /**
     * Stoppt den Listener-Thread
     * @param errorCause Fehler auf grund dessen die Verbindung abgebaut wird Weiterreichen an TcpClient.
     */
    public void stop(Exception errorCause) {
        this.errorCause = errorCause;
        stopRequest = true;
    }

    // Der eigentliche Thread
    class WorkerThread extends Thread {
        @Override
        public void run() {
            Log.d(LOG_TAG, "TcpListner started");

            while (!stopRequest) {
                try {
                    String text = channel.readLine();
                    if (text != null) {
                        if (!stopRequest)
                            client.messageReceived(text);
                    }
                } catch (SocketTimeoutException e) {
                    // nichts zu tun
                } catch (Exception ex) { // Verbindung getrennt
                    errorCause = ex;
                    break;
                }
                Thread.yield();
            }

            if (stopRequest)
                Log.d(LOG_TAG, "TcpListner stopped");
            else
                Log.d(LOG_TAG, "TcpListner aborted");

            client.listenerStopped(errorCause);
        }
    }

}