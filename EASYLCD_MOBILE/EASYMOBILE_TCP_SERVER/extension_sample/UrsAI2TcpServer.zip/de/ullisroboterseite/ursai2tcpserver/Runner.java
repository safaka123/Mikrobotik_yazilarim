package de.ullisroboterseite.ursai2tcpserver;

/**
 * Einfache Ausführung in einem Thread.
 */
public class Runner {
    /**
     * Führt eine Methode in einem sepatem Thread aus.
     * @param r Runable mit dem auszuführenden Code.
     *
     * Beispiel:

    Runner.start(new Runnable() {
        public void run() {
            whatEverToBeDone();
        }
    });

     *
     */
    static void start(Runnable r) {
        Thread t1 = new Thread(r);
        t1.start();
    }

}
