package de.ullisroboterseite.ursai2tcpserver;

import android.util.Log;

import java.net.*;
import java.nio.charset.Charset;

// Kapselt die internen TCP-Funktionalitäten und Objekte.

class TcpClient {
    static final String LOG_TAG = UrsAI2TcpServer.LOG_TAG;

    UrsAI2TcpServer eventListener = null;

    int clientID;
    TcpChannel tcpChannel = null;
    TcpListener tcpListener = null;

    String ipAddress;

    TcpClient(int clientID, UrsAI2TcpServer eventListener, Socket clientSocket, int socketTimeout, Charset charset, char ignoreTestChar) {
        this.eventListener = eventListener;
        this.clientID = clientID;
        ipAddress = clientSocket.getInetAddress().toString().substring(1);

        try {
            tcpChannel = new TcpChannel(this, clientSocket, socketTimeout, charset, ignoreTestChar);
        } catch (Exception e) {
            listenerStopped(e);
            return;
        }

        tcpListener = new TcpListener(this);
        tcpListener.start(tcpChannel);
    }

    /**
     * Trennt die TCP-Verbindung.
     */
    void disconnect() {
        tcpListener.stop(null);
    }

    /**
     * Schreibt einen Text in den Output-Stream.
     * Der sofortige Versand ist nicht garantiert.
     * @param msg Der zu versendende Text.
     */
    void write(String msg) {
        tcpChannel.out(msg, false, false, 0);
    }

    /**
     * Schreibt einen Text in den Output-Stream.
     * Hängt ein LF an den Text an und erzwingt den Versand der Nachricht.
     * @param msg Der zu versendende Text.
     * @param crlf True: CRLF anhängen, false: LF anhängen
     */
    void writeln(String msg, Boolean crlf, int crlfDelay) {
        tcpChannel.out(msg, true, crlf, crlfDelay);
    }

    /**
     * Sendet verzögert zweimal das Testzeichen.
     * @param ignoreTestChar
     * @param crlfDelay
     */
    void testConnection(char ignoreTestChar, int crlfDelay) {
        tcpChannel.testConnection(ignoreTestChar, crlfDelay);
    }

    /**
    * Der Listener-Thread ist beendet.
    * Wird von TcpListener aufgerufen.
    * Wird aus separatem Thread aufgerufen.
     * @param errorCause Fehlerursache. null bei kein Fehler
     */
    void listenerStopped(Exception errorCause) {
        tcpChannel.disconnect();
        eventListener.clientDisconnected(clientID, ipAddress, errorCause);
    }

    /**
     * Es wurde eine Nachricht (-enzeile) empfangen.
     * Wird von TcpListener aufgerufen.
     * Wird aus separatem Thread aufgerufen.
     * @param text Die empfangene Nachricht.
     */
    void messageReceived(String text) {
        eventListener.MessageReceived(clientID, text);
    }

    /**
    * Fehler beim Schreiben.
    * Wird von TcpChannel aufgerufen.
    * Wird aus separatem Thread aufgerufen.
    * @param errorCause Fehlerursache
    */
    void ioError(Exception errorCause) {
        if (errorCause != null)
            eventListener.raiseErrorOccured("Write/Writeln", ErrorCode.ConnectionFault, errorCause);
        tcpListener.stop(errorCause);
    }
}