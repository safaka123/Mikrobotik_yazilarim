package de.ullisroboterseite.ursai2tcpserver;

// Dient zur Strukturierung des Codes

// Implementiert die Charset-Methoden

import java.nio.charset.Charset;

import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.*;
import com.google.appinventor.components.common.*;

import android.os.Handler;
// import android.util.Log;

@SimpleObject(external = true)
public class TcpProperties extends AndroidNonvisibleComponent {
    static final String LOG_TAG = "TCP";

    final Handler handler = new Handler();

    final TcpProperties thisInstance = this;

    String charSetName = Charset_UTF8();
    Charset charset = Charset.forName(charSetName);

    TcpServer server = null;

    int ioTimeout = 1000;
    int localPort = 80;
    boolean isRunning = false;

    String lastErrMsg = ""; // Text des letzten Fehlers
    int lastErrorCode = 0; // Fehlercode des letzten Fehlers
    String lastAction = ""; // Fehlercode des letzten Fehlers
    String exceptionCause = ""; // ggf. die letzte Exception

    boolean lineDelimiterCrLf = false; // Zeilenendekennzeichen
    int crlfDelay = 200;
    char ignoreTestChar = (char) 6;

    TcpProperties(ComponentContainer container) {
        super(container.$form());
    }

    @SimpleProperty(description = "Charset name for character set US-ASCII.")
    public String Charset_USASCII() {
        return "US-ASCII";
    }

    @SimpleProperty(description = "Charset name for character set UTF-8.")
    public String Charset_UTF8() {
        return "UTF-8";
    }

    @SimpleProperty(description = "Charset name for character set ISO-8859-1, ISO Latin Alphabet No. 1, a.k.a. ISO-LATIN-1.")
    public String Charset_ISO_Latin_1() {
        return "ISO-8859-1";
    }

    @SimpleProperty(description = "Charset name for character set Sixteen-bit UCS Transformation Format, big-endian byte order.")
    public String Charset_UTF16BE() {
        return "UTF-16BE";
    }

    @SimpleProperty(description = "Charset name for character set Sixteen-bit UCS Transformation Format, little-endian byte order.")
    public String Charset_UTF16BL() {
        return "UTF-16BL";
    }

    @SimpleProperty(description = "Charset name for character set Sixteen-bit UCS Transformation Format, byte order identified by an optional byte-order mark.")
    public String Charset_UTF16() {
        return "UTF-16";
    }

    @SimpleProperty(description = "Charset for encoding and decoding the IO streams.")
    public String Charset() {
        return charSetName;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_STRING, defaultValue = "UTF-8")
    @SimpleProperty(description = "Charset for encoding and decoding the IO streams.")
    public void Charset(String value) {
        try {
            charset = Charset.forName(value);
            charSetName = value;
        } catch (Exception e) {
            // nichts zu tun
        }
    }

    @SimpleProperty(description = "Returns the IP address of the local host. An empty string if not connected to a network.")
    public String LocalHost() {
        return Helpers.getLocalHostString();
    }

    @SimpleProperty(description = "Returns the IPv4 addresses of all known network interfaces.")
    public YailList NICList() {
        return YailList.makeList(Helpers.getNICNames());
    }

    @SimpleProperty(description = "Timeout in milliseconds for I/O operation. Default is 1000 ms. 0: infinite.")
    public int IoTimeout() {
        return ioTimeout;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_NON_NEGATIVE_INTEGER, defaultValue = "1000")
    @SimpleProperty(description = "Timeout in milliseconds for connecting to a server. Default is 1000 ms. 0: infinite.")
    public void IoTimeout(int value) {
        if (value >= 0)
            ioTimeout = value;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_INTEGER, defaultValue = "80")
    @SimpleProperty(description = "Port on which the server is listening.")
    public void LocalPort(int value) {
        localPort = value;
    }

    @SimpleProperty(description = "Port on which the server is listening.")
    public int LocalPort() {
        return localPort;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN, defaultValue = "false")
    @SimpleProperty(description = "false: terminates line with LF, true: with CRLF.")
    public void LineDelimiterCrLf(boolean value) {
        lineDelimiterCrLf = value;
    }

    @SimpleProperty(description = "false: terminates line with LF, true: with CRLF.")
    public boolean LineDelimiterCrLf() {
        return lineDelimiterCrLf;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_NON_NEGATIVE_INTEGER, defaultValue = "200")
    @SimpleProperty(description = "CRLF is send after this delay (millisseconds).")
    public void CrLfDelay(int value) {
        crlfDelay = value;
    }

    @SimpleProperty(description = "CRLF is send after this delay (millisseconds).")
    public int CrLfDelay() {
        return crlfDelay;
    }

    @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_NON_NEGATIVE_INTEGER, defaultValue = "6")
    @SimpleProperty(description = "Ignore this character in the input stream.")
    public void IgnoreTestChar(int value) {
        ignoreTestChar = (char) value;
    }

    @SimpleProperty(description = "Ignore this character in the input stream..")
    public int IgnoreTestChar() {
        return ignoreTestChar;
    }

    @SimpleProperty(description = "true: The server accepts clients.")
    public boolean IsRunning() {
        return isRunning;
    }

    @SimpleProperty(description = "Gets the number of currently connected clients.")
    public int ConnectedClients() {
        return server.getConnectedClients();
    }

    @SimpleFunction(description = "Gets a list of currently connected clients.")
    public YailList GetClientIDs() {
        return YailList.makeList(server.clients.keySet());
    }

    //======= Error Handling ==================================================
    @SimpleProperty(description = "Returns a text message about the last error.")
    public String LastErrorMessage() {
        return lastErrMsg;
    }

    @SimpleProperty(description = "Returns the code of the last error.")
    public int LastErrorCode() {
        return lastErrorCode;
    }

    @SimpleProperty(description = "Returns the last Action the error code belongs to.")
    public String LastAction() {
        return lastAction;
    }

    @SimpleProperty(description = "Provides information on the last exception.")
    public String LastExecptionCause() {
        return exceptionCause;
    }

    void resetErrorInfo(String ActionName) {
        lastErrMsg = ""; // Text des letzten Fehlers
        lastErrorCode = 0; // Fehlercode des letzten Fehlers
        ActionName = ""; // Fehlercode des letzten Fehlers
        exceptionCause = ""; // ggf. die letzte Exception
    }

    @SimpleEvent(description = "Error occurred.")
    public void ErrorOccurred(final String ActionName, final int ErrorCode, final String ErrorMessage) {
        handler.post(new Runnable() {
            public void run() {
                EventDispatcher.dispatchEvent(thisInstance, "ErrorOccurred", ActionName, ErrorCode, ErrorMessage);
            }
        });
    }

    void raiseErrorOccured(String actionName, ErrorCode errorCode, Exception errorCause) {
        exceptionCause = "";

        if (errorCause != null)
            exceptionCause = errorCause.toString();

        lastErrMsg = errorCode.toString();
        lastErrorCode = errorCode.ordinal();
        lastAction = actionName;
        ErrorOccurred(actionName, lastErrorCode, lastErrMsg);
    }

}