package de.ullisroboterseite.ursai2tcpserver;

// Autor: https://UllisRoboterSeite.de

// Doku:  https://UllisRoboterSeite.de/public/android-AI2-TCPServer.html
//
// Version 1.0 (2021-04-15)
// -------------------------
// - Basis-Version
//

import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.runtime.*;
import com.google.appinventor.components.runtime.util.*;

import android.util.Log;

@DesignerComponent(version = 1, //
        versionName = UrsAI2TcpServer.VersionName, //
        dateBuilt = UrsAI2TcpServer.dateBuilt, //
        description = "TCP server for AI2.", //
        category = com.google.appinventor.components.common.ComponentCategory.EXTENSION, //
        nonVisible = true, //
        helpUrl = "https://UllisRoboterSeite.de/android-AI2-TCPServer.html", //
        iconName = "aiwebres/icon.png")
@SimpleObject(external = true)
@UsesPermissions(permissionNames = "android.permission.INTERNET,android.permission.ACCESS_NETWORK_STATE")
public class UrsAI2TcpServer extends TcpProperties implements OnDestroyListener {
    static final String LOG_TAG = "TCP";
    static final String VersionName = "1.0.0";
    static final String dateBuilt = "2021-04-15";

    public UrsAI2TcpServer(ComponentContainer container) {
        super(container);
        form.registerForOnDestroy(this);
        server = new TcpServer(this, ignoreTestChar, crlfDelay);
    } // ctor

    @SimpleFunction(description = "Starts the TCP server.")
    public void Start() {
        resetErrorInfo("Start");
        server.ignoreTestChar = ignoreTestChar;
        server.start(localPort, ioTimeout, charset);
    }

    @SimpleFunction(description = "Stops the TCP server.")
    public void Stop() {
        resetErrorInfo("Stop");
        server.stop();

        // Meldung über vollzogene Trennung kommt aus den Threads
    }

    @SimpleFunction(description = "Writes text to the output stream. Does not transmit.")
    public void Write(int ClientID, String Message) {
        resetErrorInfo("Write");
        TcpClient client = server.getClient(ClientID);
        if (client != null)
            client.write(Message);
        else
            raiseErrorOccured("Write", ErrorCode.InvalidClientID, null);
    }

    //TODO: erkennt eine abgebrochene Verbindung erst beim 2. Mal.
    @SimpleFunction(description = "Writes text to the output stream, adds an end of line identifier and transmits the pending data.")
    public void Writeln(int ClientID, String Message) {
        resetErrorInfo("Writeln");
        TcpClient client = server.getClient(ClientID);
        if (client != null)
            client.writeln(Message, lineDelimiterCrLf, crlfDelay);
        else
            raiseErrorOccured("Write", ErrorCode.InvalidClientID, null);
    }

    @SimpleFunction(description = "Writes the IgnoreTestChar twice with a delay. If Delay < 0, CrLfDelay is used.")
    public void TestConnection(int ClientID, int Delay) {
        resetErrorInfo("TestConnection");
        if (Delay < 0)
            Delay = crlfDelay;
        TcpClient client = server.getClient(ClientID);
        if (client != null)
            client.testConnection(ignoreTestChar, Delay);
        else
            raiseErrorOccured("Write", ErrorCode.InvalidClientID, null);
    }

    @Override
    public void onDestroy() {
        try {
            server.stop();// Ereignisse werden von AI2 nicht mehr ausgelöst.
        } catch (Exception e) {
            // nichts zu tun
        }
    }

    //=========================================
    // Listener
    //=========================================

    void serverStarted() { // wird aus Thread aufgerufen
        isRunning = true;
        ServerStarted();
    }

    void serverStopped(ErrorCode errorCode, Throwable ex) { // wird aus Thread aufgerufen
        isRunning = false;

        exceptionCause = "";
        if (ex != null)
            exceptionCause = ex.toString();

        lastErrMsg = errorCode.toString();
        lastErrorCode = errorCode.ordinal();
        lastAction = "ServerThread";

        ServerStopped(errorCode.errorCode);
    }

    void clientConnected(int clientID, String clientIP) { // wird aus Thread aufgerufen
        ClientConnected(clientID, clientIP);
    }

    void clientDisconnected(int clientID, String clientIP, Exception errorCause) { // wird aus Thread aufgerufen
        server.removeClient(clientID);
        ClientDisconnected(clientID, clientIP);
    }

    //=========================================
    // Events
    //=========================================

    @SimpleEvent(description = "Server has started.")
    public void ServerStarted() {
        handler.post(new Runnable() { // Ggf. wird dieses Ereignis in einem Thread ausgelöst.
            public void run() {
                EventDispatcher.dispatchEvent(thisInstance, "ServerStarted");
            }
        });
    }

    @SimpleEvent(description = "Server has stopped.")
    public void ServerStopped(final int ErrorCode) {
        handler.post(new Runnable() { // Ggf. wird dieses Ereignis in einem Thread ausgelöst.
            public void run() {
                EventDispatcher.dispatchEvent(thisInstance, "ServerStopped", ErrorCode);
            }
        });
    }

    @SimpleEvent(description = "Server has stopped.")
    public void ClientConnected(final int ClientID, final String ClientIP) {
        handler.post(new Runnable() { // Ggf. wird dieses Ereignis in einem Thread ausgelöst.
            public void run() {
                EventDispatcher.dispatchEvent(thisInstance, "ClientConnected", ClientID, ClientIP);
            }
        });
    }

    @SimpleEvent(description = "Server has stopped.")
    public void ClientDisconnected(final int ClientID, final String ClientIP) {
        handler.post(new Runnable() { // Ggf. wird dieses Ereignis in einem Thread ausgelöst.
            public void run() {
                EventDispatcher.dispatchEvent(thisInstance, "ClientDisconnected", ClientID, ClientIP);
            }
        });
    }

    @SimpleEvent(description = "Message received. Event is fired when a line feed (\\n) was received.")
    public void MessageReceived(final int ClientID, final String Message) {
        handler.post(new Runnable() { // Ggf. wird dieses Ereignis in einem Thread ausgelöst.
            public void run() {
                EventDispatcher.dispatchEvent(thisInstance, "MessageReceived", ClientID, Message);
            }
        });
    }
}